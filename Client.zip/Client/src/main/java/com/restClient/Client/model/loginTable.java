
package com.restClient.Client.model;

public class loginTable{
    
    private long rn;
    
    private String email;
    
    private String pass;

    public long getRn() {
        return rn;
    }

    public void setRn(long rn) {
        this.rn = rn;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    
    
}
