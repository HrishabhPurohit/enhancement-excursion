
package com.restClient.Client.client_config;

import com.restClient.Client.model.loginTable;
import java.util.Base64;
//import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class Client /* implements CommandLineRunner*/{
    
    //log4j
    
    public static void main(String[] args){
    
        Client client = new Client();
        client.getCreds();
    }
    
    private void getCreds(){
        
        String uid = "1521019@kiit.ac.in";
        String pid = "hrishabh";
        consumeService(uid,pid);
    }
    
    public void consumeService(String usr, String pass){
        String base64auth = encoder(usr,pass);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization","Basic " + base64auth);
        
        HttpEntity<String> req = new HttpEntity<String>(headers); 
        
        RestTemplate rt = new RestTemplate();
        String uri = "http://localhost:8788/api/2.0/students";
        ResponseEntity<loginTable> res = rt.exchange(uri, HttpMethod.GET, req, loginTable.class);
        loginTable lg = res.getBody();
        System.out.println("The roll no is : " + lg.getRn());
    }
    
//    public void encodeDecode(){
//    
//        String user = "hrishabh";
//        String pwd = "iAmAwesome";
//        String encodedString = encoder(user,pwd);
//        String deocdedString = decoder(encodedString);
//        System.out.println("Encoded String: "+encodedString);        
//        System.out.println("Decoded String: "+deocdedString);
//        
//    }
    
//    private String decoder(String encodedString){
//    
//        byte[] b64 = Base64.getDecoder().decode(encodedString.getBytes());
//        String decodedString = new String(b64);        
//        return decodedString;
//    }
    
    private String encoder(String user, String pwd){
        String base64 = user+":"+pwd;
        byte[] b64 = Base64.getEncoder().encode(base64.getBytes());
        String base64auth = new String(b64);
        return base64auth;
    }

    /*
    @Override
    public void run(String... strings) throws Exception {
        consumeService();
    }*/
}
