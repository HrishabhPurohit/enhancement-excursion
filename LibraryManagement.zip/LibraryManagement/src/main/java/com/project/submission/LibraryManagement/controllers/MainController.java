package com.project.submission.LibraryManagement.controllers;

import com.project.submission.LibraryManagement.models.Book;
import com.project.submission.LibraryManagement.services.BookService;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
    @Autowired
    private BookService bk_service;
    
    @GetMapping("/hellojsp")
    public String init(HttpServletRequest r){
        r.setAttribute("books", bk_service.findbooks());
        r.setAttribute("mode","BOOK_VIEW");
        return "index";
    }
    @GetMapping("/update")
    public String update(@RequestParam long id,HttpServletRequest r){
        r.setAttribute("book", bk_service.findone(id));
        r.setAttribute("mode","BOOK_EDIT");
        return "index";
    }
    @InitBinder
    public void initBinder(WebDataBinder binder){
        binder.registerCustomEditor(Date.class,new CustomDateEditor(new SimpleDateFormat("yyyy-mm-dd"),false));
    }
    
    @PostMapping("/save")
    public void save(@ModelAttribute Book book,BindingResult bindingresult,HttpServletRequest r,HttpServletResponse res) throws IOException{
        bk_service.save(book);
        r.setAttribute("books", bk_service.findbooks());
        r.setAttribute("mode","BOOK_VIEW");
        res.sendRedirect("/hellojsp");
    }
    @GetMapping("/newbook")
    public String newbook(HttpServletRequest req){
        req.setAttribute("mode","BOOK_NEW");
        return "index";
    }
    @GetMapping("/delete")
    public void deletebook(@RequestParam long id,HttpServletRequest req,HttpServletResponse res) throws IOException{
        bk_service.deleteBook(id);
        req.setAttribute("mode","BOOK_NEW");
        res.sendRedirect("/hellojsp");
    }
}
