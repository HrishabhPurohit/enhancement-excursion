package com.project.submission.LibraryManagement.models;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;


@Entity(name = "books")
public class Book implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator="my_seq")
    @SequenceGenerator(name="my_seq", sequenceName="my_seq")
    private long id;
    @Column(name="book_name")
    private String bn;
    @Column(name="author")
    private String athr;
    @Column(name="purchase_date")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date pd;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBn() {
        return bn;
    }

    public void setBn(String bn) {
        this.bn = bn;
    }

    public String getAthr() {
        return athr;
    }

    public void setAthr(String athr) {
        this.athr = athr;
    }

    public Date getPd() {
        return pd;
    }

    public void setPd(Date pd) {
        this.pd = pd;
    }
    
}
