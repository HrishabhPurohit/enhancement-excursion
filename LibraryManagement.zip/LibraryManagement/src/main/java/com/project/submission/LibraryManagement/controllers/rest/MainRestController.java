package com.project.submission.LibraryManagement.controllers.rest;

import com.project.submission.LibraryManagement.models.Book;
import com.project.submission.LibraryManagement.services.BookService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainRestController {
    
    @Autowired
    private BookService bk_service;
    
    @GetMapping("/yourbooks/all")
    public List<Book> getbooks(){
        return bk_service.findbooks();
    }
   
    @GetMapping("/yourbooks/{id}")
    public Book getbooks(@PathVariable long id){

        return bk_service.findbook(id);
    }
    
    @GetMapping("/delete/{id}")
    public void delete(@PathVariable long id){
        bk_service.deleteBook(id);
    }
}
