
package com.project.submission.LibraryManagement.dao;

import com.project.submission.LibraryManagement.models.Book;
import org.springframework.data.repository.CrudRepository;

public interface Repo extends CrudRepository<Book,Long>{
    
}
