
package com.project.submission.LibraryManagement.services;

import com.project.submission.LibraryManagement.dao.Repo;
import com.project.submission.LibraryManagement.models.Book;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BookService {
    @Autowired
    private Repo bk_repo;
    
    public List<Book> findbooks(){
        List<Book> stuff = new ArrayList<Book>();
        for(Book bk : bk_repo.findAll()){
            stuff.add(bk);
        }
        return stuff;
    }
    
     public Book findbook(Long id){
        return bk_repo.findOne(id);
    }
    
    public void deleteBook(long id){
        bk_repo.delete(id);
    }
    public Book findone(long id){
        return bk_repo.findOne(id);
    }
    public void save(Book book){
        bk_repo.save(book);
    }
}
